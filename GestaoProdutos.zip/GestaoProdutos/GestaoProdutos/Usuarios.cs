﻿using System.Security.Cryptography;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace GestaoProdutos
{
    public class Usuarios
    {
        // Atributos privados
        private int id;
        private string nome;
        private string email;
        private string senha;
        private string nomeUsuario;
        private string cpf;
        private string login;

        // Construtor para inicializar um novo usuário
        public Usuarios(string nome, string email, string senha, string nomeUsuario, string cpf, string login)
        {
            this.nome = nome;
            this.email = email;
            this.senha = senha;
            this.nomeUsuario = nomeUsuario;
            this.cpf = cpf;
            this.login = login;
        }

        public Usuarios()
        {

        }

        // Propriedades para acessar os campos privados
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public string NomeUsuario
        {
            get { return nomeUsuario; }
            set { nomeUsuario = value; }
        }

        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }

        public string Login
        {
            get { return login; }
            set { login = value; }
        }

        // Verificar se o e-mail é válido
        public static bool verificarEmail(string email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zAZ0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(email);
        }

        // Criptografar senha
        public static string CriptografarSenha(string senha)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(senha));
                return string.Concat(bytes.Select(b => b.ToString("x2")));
            }
        }

        // Validar CPF
        public static bool ValidarCPF(string cpf)
        {
            cpf = new string(cpf.Where(char.IsDigit).ToArray());

            if (cpf.Length != 11 || cpf.Distinct().Count() == 1)
                return false;

            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += (cpf[i] - '0') * (10 - i);

            int primeiroDigito = soma % 11;
            primeiroDigito = (primeiroDigito < 2) ? 0 : 11 - primeiroDigito;

            if ((cpf[9] - '0') != primeiroDigito)
                return false;

            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += (cpf[i] - '0') * (11 - i);

            int segundoDigito = soma % 11;
            segundoDigito = (segundoDigito < 2) ? 0 : 11 - segundoDigito;

            return (cpf[10] - '0') == segundoDigito;
        }

        // Cadastrar um novo usuário no banco de dados
        public bool CadastrarUsuario()
        {
            using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
            {
                string senhaCriptografada = CriptografarSenha(senha);
                string query = "INSERT INTO usuarios (nome, email, cpf, nome_usuario, senha) VALUES (@nome, @email, @cpf, @nome_usuario, @senha);";
                MySqlCommand comando = new MySqlCommand(query, conexaoBanco);

                comando.Parameters.AddWithValue("@nome", nome);
                comando.Parameters.AddWithValue("@email", email);
                comando.Parameters.AddWithValue("@cpf", cpf);
                comando.Parameters.AddWithValue("@nome_usuario", nomeUsuario);
                comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                return comando.ExecuteNonQuery() > 0;
            }
        }

        // Verificar se o usuário já existe (com base no email ou CPF)
        public bool UsuarioExiste(string email, string cpf)
        {
            using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
            {
                string query = "SELECT COUNT(*) FROM usuarios WHERE email = @Email OR cpf = @CPF";
                MySqlCommand comando = new MySqlCommand(query, conexaoBanco);
                comando.Parameters.AddWithValue("@Email", email);
                comando.Parameters.AddWithValue("@CPF", cpf);

                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
        }

        // Verifica se o login (email ou nome de usuário) existe no banco de dados
        public static bool LoginExiste(string login)
        {
            using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
            {
                string query = "SELECT COUNT(*) FROM usuarios WHERE email = @login OR nome_usuario = @login";
                MySqlCommand comando = new MySqlCommand(query, conexaoBanco);
                comando.Parameters.AddWithValue("@login", login);

                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
        }

        // Verifica se login e senha estão corretos
        public static bool ValidarLogin(string login, string senha)
        {
            string senhaCriptografada = CriptografarSenha(senha);

            using (MySqlConnection conexao = new ConexaoBD().Conectar())
            {
                string query = "SELECT COUNT(*) FROM usuarios WHERE (email = @login OR nome_usuario = @login) AND senha = @senha";
                MySqlCommand comando = new MySqlCommand(query, conexao);
                comando.Parameters.AddWithValue("@login", login);
                comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                return Convert.ToInt32(comando.ExecuteScalar()) > 0;
            }
        }

        //Método Redefinir Senha
        public bool RedefinirSenha()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
                {
                    string senhaCriptografada = CriptografarSenha(Senha);
                    string redefinir = "UPDATE usuarios SET senha = @senha WHERE email = @Email";

                    MySqlCommand comando = new MySqlCommand(redefinir, conexaoBanco);
                    comando.Parameters.AddWithValue("@senha", senhaCriptografada);
                    comando.Parameters.AddWithValue("@Email", Email);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao redefinir a senha -> " + ex.Message);
                return false;
            }
        }

        // Método que busca no banco de dados os dados completos de um usuário autenticado
        public static Usuarios BuscarUsuarioAutenticado(string login, string senha)
        {
            // Criptografa a senha digitada para comparar com a senha salva no banco
            string senhaCriptografada = CriptografarSenha(senha);

            // Abre a conexão com o banco de dados
            using (MySqlConnection conexao = new ConexaoBD().Conectar())
            {
                // Consulta SQL para verificar se existe um usuário com o login (e-mail ou nome de usuário) e senha informados
                string query = "SELECT id_usuario, nome, email, cpf, nome_usuario FROM usuarios " +
                               "WHERE (email = @login OR nome_usuario = @login) AND senha = @senha";

                MySqlCommand comando = new MySqlCommand(query, conexao);
                comando.Parameters.AddWithValue("@login", login);
                comando.Parameters.AddWithValue("@senha", senhaCriptografada);

                // Executa a consulta e lê os resultados
                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        // Cria um objeto da classe Usuarios e preenche com os dados do banco
                        Usuarios usuario = new Usuarios();
                        usuario.Id = reader.GetInt32("id_usuario");
                        usuario.Nome = reader.GetString("nome");
                        usuario.Email = reader.GetString("email");
                        usuario.Cpf = reader.GetString("cpf");
                        usuario.NomeUsuario = reader.GetString("nome_usuario");

                        // Retorna o objeto preenchido com os dados do usuário autenticado
                        return usuario;
                    }
                }
            }
            // Retorna null se o login falhar (usuário não encontrado ou senha incorreta)
            return null;
        }
    }
}
