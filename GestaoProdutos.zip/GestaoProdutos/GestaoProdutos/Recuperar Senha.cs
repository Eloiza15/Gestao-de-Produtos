﻿namespace GestaoProdutos
{
    public partial class Recuperar_Senha : UserControl
    {
        public Recuperar_Senha()
        {
            InitializeComponent();
        }

        // Método para limpar os campos de entrada
        private void LimparCampos()
        {
            txtEmail.Clear();
            txtNovaSenha.Clear();
        }


        // Evento ao clicar no botão para redefinir a senha
        private void btnRedefinir_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txtEmail.Text;
                string novaSenha = txtNovaSenha.Text;

                // 1. Verifica se os campos foram preenchidos
                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(novaSenha))
                {
                    MessageBox.Show("Preencha todos os campos antes de continuar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Verifica se o e-mail informado é válido
                if (!Usuarios.verificarEmail(email))
                {
                    MessageBox.Show("Formato de e-mail inválido. Digite um e-mail válido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 3. Tenta redefinir a senha
                Usuarios usuarios = new Usuarios();
                usuarios.Email = email;
                usuarios.Senha = novaSenha;

                if (usuarios.RedefinirSenha())
                {
                    MessageBox.Show("Senha atualizada com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Limpa os campos após redefinir com sucesso
                    LimparCampos();

                    // Voltar para a tela de login
                    Form formularioPrincipal = this.FindForm();
                    if (formularioPrincipal is Cadastro formCadastro)
                    {
                        Login login = new Login();
                        formCadastro.adicionarUserControl(login);
                    }
                }
                else
                {
                    MessageBox.Show("Não foi possível atualizar a senha. Verifique se o e-mail está cadastrado no sistema.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao tentar redefinir a senha: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
