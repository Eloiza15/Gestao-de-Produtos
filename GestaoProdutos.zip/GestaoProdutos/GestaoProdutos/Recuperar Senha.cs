﻿namespace GestaoProdutos
{
    public partial class Recuperar_Senha : UserControl
    {
        public Recuperar_Senha()
        {
            InitializeComponent();
        }
    }
}
