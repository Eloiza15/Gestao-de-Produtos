﻿namespace GestaoProdutos
{
    partial class Login
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lblNomeTela = new Label();
            lblNomeUsuorSenha = new Label();
            lblSenha = new Label();
            llblFazerCadastro = new LinkLabel();
            llblEsqueciSenha = new LinkLabel();
            txtNomeUsuorSenha = new TextBox();
            txtSenha = new TextBox();
            btnLogin = new Button();
            SuspendLayout();
            // 
            // lblNomeTela
            // 
            lblNomeTela.AutoSize = true;
            lblNomeTela.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNomeTela.ForeColor = Color.Indigo;
            lblNomeTela.Location = new Point(336, 33);
            lblNomeTela.Margin = new Padding(6, 0, 6, 0);
            lblNomeTela.Name = "lblNomeTela";
            lblNomeTela.Size = new Size(95, 34);
            lblNomeTela.TabIndex = 1;
            lblNomeTela.Text = "Login";
            // 
            // lblNomeUsuorSenha
            // 
            lblNomeUsuorSenha.AutoSize = true;
            lblNomeUsuorSenha.Location = new Point(40, 99);
            lblNomeUsuorSenha.Margin = new Padding(4, 0, 4, 0);
            lblNomeUsuorSenha.Name = "lblNomeUsuorSenha";
            lblNomeUsuorSenha.Size = new Size(333, 29);
            lblNomeUsuorSenha.TabIndex = 2;
            lblNomeUsuorSenha.Text = "E-mail ou Nome de Usuário:";
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(40, 139);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(92, 29);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            // 
            // llblFazerCadastro
            // 
            llblFazerCadastro.AutoSize = true;
            llblFazerCadastro.Location = new Point(142, 273);
            llblFazerCadastro.Name = "llblFazerCadastro";
            llblFazerCadastro.Size = new Size(474, 29);
            llblFazerCadastro.TabIndex = 4;
            llblFazerCadastro.TabStop = true;
            llblFazerCadastro.Text = "Não possui cadastro? Faça o seu agora!";
            llblFazerCadastro.LinkClicked += llblFazerCadastro_LinkClicked;
            // 
            // llblEsqueciSenha
            // 
            llblEsqueciSenha.AutoSize = true;
            llblEsqueciSenha.Location = new Point(89, 328);
            llblEsqueciSenha.Name = "llblEsqueciSenha";
            llblEsqueciSenha.Size = new Size(570, 29);
            llblEsqueciSenha.TabIndex = 5;
            llblEsqueciSenha.TabStop = true;
            llblEsqueciSenha.Text = "Esqueceu sua senha? Clique aqui para redefinir!";
            llblEsqueciSenha.LinkClicked += llblEsqueciSenha_LinkClicked;
            // 
            // txtNomeUsuorSenha
            // 
            txtNomeUsuorSenha.Location = new Point(394, 96);
            txtNomeUsuorSenha.MaxLength = 200;
            txtNomeUsuorSenha.Name = "txtNomeUsuorSenha";
            txtNomeUsuorSenha.Size = new Size(332, 35);
            txtNomeUsuorSenha.TabIndex = 1;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(394, 136);
            txtSenha.MaxLength = 8;
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(332, 35);
            txtSenha.TabIndex = 2;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(321, 201);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(119, 39);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Entrar";
            btnLogin.UseVisualStyleBackColor = true;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(15F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnLogin);
            Controls.Add(txtSenha);
            Controls.Add(txtNomeUsuorSenha);
            Controls.Add(llblEsqueciSenha);
            Controls.Add(llblFazerCadastro);
            Controls.Add(lblSenha);
            Controls.Add(lblNomeUsuorSenha);
            Controls.Add(lblNomeTela);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Login";
            Size = new Size(773, 397);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNomeTela;
        private Label lblNomeUsuorSenha;
        private Label lblSenha;
        private LinkLabel llblFazerCadastro;
        private LinkLabel llblEsqueciSenha;
        private TextBox txtNomeUsuorSenha;
        private TextBox txtSenha;
        private Button btnLogin;
    }
}
