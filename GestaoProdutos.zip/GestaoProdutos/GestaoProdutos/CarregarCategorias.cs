﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace GestaoProdutos
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string NomeCategoria { get; set; }
    }

    public class CarregarCategorias
    {
        // Método para listar as categorias do banco de dados
        public static List<Categoria> ListarCategorias()
        {
            List<Categoria> categorias = new List<Categoria>();
            ConexaoBD conexaoBD = new ConexaoBD();
            MySqlConnection conexao = conexaoBD.Conectar();

            // Consulta SQL para pegar todas as categorias
            string query = "SELECT * FROM categorias";

            MySqlCommand cmd = new MySqlCommand(query, conexao);
            MySqlDataReader reader = cmd.ExecuteReader();

            // Lendo os dados e armazenando na lista
            while (reader.Read())
            {
                categorias.Add(new Categoria
                {
                    IdCategoria = int.Parse(reader["id_categoria"].ToString()),
                    NomeCategoria = reader["nome_categoria"].ToString()
                });
            }

            conexao.Close();
            return categorias;
        }
    }
}
