﻿namespace GestaoProdutos
{
    public partial class GerenciamentoProdutos : Form
    {
        public GerenciamentoProdutos()
        {
            InitializeComponent();
        }

        private void GerenciamentoProdutos_Load(object sender, EventArgs e)
        {

        }

        private void GerenciamentoProdutos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Fecha o programa inteiro
        }
    }
}
