﻿using static GestaoProdutos.CarregarCategorias;

namespace GestaoProdutos
{
    public partial class GerenciamentoProdutos : Form
    {
        public GerenciamentoProdutos()
        {
            InitializeComponent();
        }

        private void GerenciamentoProdutos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Fecha o programa inteiro
        }

        // Método responsável por carregar as categorias no ComboBox
        private void CarregarCategoriasComboBox()
        {
            cbxCategoria.Items.Clear();

            // Chama o método que retorna a lista de categorias do banco de dados
            List<Categoria> categorias = CarregarCategorias.ListarCategorias();

            // Percorre cada categoria e adiciona o nome ao ComboBox
            foreach (Categoria categoria in categorias)
            {
                cbxCategoria.Items.Add(categoria.NomeCategoria);
            }
        }

        private void GerenciamentoProdutos_Load(object sender, EventArgs e)
        {
            CarregarCategoriasComboBox(); // Chama a função ao carregar o formulário

        }
    }
}
