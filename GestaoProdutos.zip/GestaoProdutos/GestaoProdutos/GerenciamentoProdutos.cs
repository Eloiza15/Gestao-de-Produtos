﻿namespace GestaoProdutos
{
    public partial class GerenciamentoProdutos : Form
    {
        public GerenciamentoProdutos()
        {
            InitializeComponent();
        }
    }
}
