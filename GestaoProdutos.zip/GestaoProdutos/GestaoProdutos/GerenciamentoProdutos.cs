﻿using static GestaoProdutos.CarregarCategorias;

namespace GestaoProdutos
{
    public partial class GerenciamentoProdutos : Form
    {
        public GerenciamentoProdutos()
        {
            InitializeComponent();
        }

        private void GerenciamentoProdutos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Fecha o programa inteiro
        }

        // Método responsável por carregar as categorias no ComboBox
        private void CarregarCategoriasComboBox()
        {
            // Chama o método que retorna a lista de categorias do banco de dados
            List<Categoria> categorias = CarregarCategorias.ListarCategorias();

            // Define o DataSource e os membros de exibição e valor
            cbxCategoria.DataSource = categorias;
            cbxCategoria.DisplayMember = "NomeCategoria"; // Propriedade que aparece na lista
            cbxCategoria.ValueMember = "IdCategoria";     // Propriedade que será usada como valor
            cbxCategoria.SelectedIndex = -1;              // Nenhum item selecionado por padrão
        }

        private void GerenciamentoProdutos_Load(object sender, EventArgs e)
        {
            CarregarCategoriasComboBox(); // Chama a função ao carregar o formulário

            Produtos produto = new Produtos();
            produto.ListarTodosProdutos(dataGridProdutos); // Chama o método para listar os produtos no DataGridView
        }

        // Método para limpar os campos
        private void LimparCampos()
        {
            // Limpa os campos de texto
            txtNomeP.Clear();
            txtPrecoP.Clear();
            txtQtEstoque.Clear();

            // Limpa o ComboBox, desmarcando qualquer item selecionado
            cbxCategoria.SelectedIndex = -1;

            txtNomeP.Focus(); // Foca no primeiro campo de entrada (nome do produto)
        }


        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNomeP.Text) ||
                    string.IsNullOrWhiteSpace(txtPrecoP.Text) ||
                    string.IsNullOrWhiteSpace(txtQtEstoque.Text) ||
                    !decimal.TryParse(txtPrecoP.Text, out _) || // Verifica se o preço é um número decimal válido
                    !int.TryParse(txtQtEstoque.Text, out _))    // Verifica se a quantidade é um número inteiro válido
                {
                    MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cbxCategoria.SelectedIndex == -1 || cbxCategoria.SelectedValue == null)
                {
                    MessageBox.Show("Selecione uma categoria!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Produtos produto = new Produtos();
                produto.Nome = txtNomeP.Text;
                produto.Preco = decimal.Parse(txtPrecoP.Text);
                produto.Quantidade = int.Parse(txtQtEstoque.Text);
                produto.IdCategoria = (int)cbxCategoria.SelectedValue;

                if (produto.InserirProduto())
                {
                    MessageBox.Show("Produto cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    produto.ListarTodosProdutos(dataGridProdutos);
                }
                else
                {
                    MessageBox.Show("Erro ao cadastrar o produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar gravar o produto.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
           
        }
    }
}
