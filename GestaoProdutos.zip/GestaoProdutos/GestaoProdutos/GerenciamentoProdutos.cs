﻿using System.Data;
using static GestaoProdutos.CarregarCategorias;

namespace GestaoProdutos
{
    public partial class GerenciamentoProdutos : Form
    {
        public GerenciamentoProdutos()
        {
            InitializeComponent();
        }

        private void GerenciamentoProdutos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Fecha o programa inteiro
        }

        // Método responsável por carregar as categorias no ComboBox
        private void CarregarCategoriasComboBox()
        {
            // Chama o método que retorna a lista de categorias do banco de dados
            List<Categoria> categorias = CarregarCategorias.ListarCategorias();

            // Define o DataSource e os membros de exibição e valor
            cbxCategoria.DataSource = categorias;
            cbxCategoria.DisplayMember = "NomeCategoria"; // Propriedade que aparece na lista
            cbxCategoria.ValueMember = "IdCategoria";     // Propriedade que será usada como valor
            cbxCategoria.SelectedIndex = -1;              // Nenhum item selecionado por padrão
        }

        private void GerenciamentoProdutos_Load(object sender, EventArgs e)
        {
            CarregarCategoriasComboBox(); // Chama a função ao carregar o formulário

            Produtos produto = new Produtos();
            produto.ListarTodosProdutos(dataGridProdutos); // Chama o método para listar os produtos no DataGridView
        }

        // Método para limpar os campos
        private void LimparCampos()
        {
            // Limpa os campos de texto
            txtID.Clear();
            txtNomeP.Clear();
            txtPrecoP.Clear();
            txtQtEstoque.Clear();

            // Limpa o ComboBox, desmarcando qualquer item selecionado
            cbxCategoria.SelectedIndex = -1;

            txtNomeP.Focus(); // Foca no primeiro campo de entrada (nome do produto)
        }

        //Evento ou clicar no botão de Inserir
        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNomeP.Text) ||
                    string.IsNullOrWhiteSpace(txtPrecoP.Text) ||
                    string.IsNullOrWhiteSpace(txtQtEstoque.Text) ||
                    !decimal.TryParse(txtPrecoP.Text, out _) || // Verifica se o preço é um número decimal válido
                    !int.TryParse(txtQtEstoque.Text, out _))    // Verifica se a quantidade é um número inteiro válido
                {
                    MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cbxCategoria.SelectedIndex == -1 || cbxCategoria.SelectedValue == null)
                {
                    MessageBox.Show("Selecione uma categoria!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Produtos produto = new Produtos();
                produto.Nome = txtNomeP.Text;
                produto.Preco = decimal.Parse(txtPrecoP.Text);
                produto.Quantidade = int.Parse(txtQtEstoque.Text);
                produto.IdCategoria = (int)cbxCategoria.SelectedValue;

                if (produto.InserirProduto())
                {
                    MessageBox.Show("Produto inserido com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    produto.ListarTodosProdutos(dataGridProdutos);
                }
                else
                {
                    MessageBox.Show("Erro ao inserir o produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao tentar inserir o produto.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Evento ou clicar no botão de Atualizar
        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("Selecione um produto para atualizar!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtNomeP.Text) ||
                    string.IsNullOrWhiteSpace(txtPrecoP.Text) ||
                    string.IsNullOrWhiteSpace(txtQtEstoque.Text) ||
                    !decimal.TryParse(txtPrecoP.Text, out _) ||
                    !int.TryParse(txtQtEstoque.Text, out _))
                {
                    MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (cbxCategoria.SelectedIndex == -1 || cbxCategoria.SelectedValue == null)
                {
                    MessageBox.Show("Selecione uma categoria!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Produtos produto = new Produtos();
                produto.IdProduto = int.Parse(txtID.Text); // ID necessário para saber o que atualizar
                produto.Nome = txtNomeP.Text;
                produto.Preco = decimal.Parse(txtPrecoP.Text);
                produto.Quantidade = int.Parse(txtQtEstoque.Text);
                produto.IdCategoria = (int)cbxCategoria.SelectedValue;

                if (produto.AtualizarProduto())
                {
                    MessageBox.Show("Produto atualizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimparCampos();
                    produto.ListarTodosProdutos(dataGridProdutos);
                }
                else
                {
                    MessageBox.Show("Erro ao atualizar o produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar o produto.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Evento ou clicar no botão de Excluir
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtID.Text))
                {
                    MessageBox.Show("Selecione um produto para excluir!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirm = MessageBox.Show("Tem certeza que deseja excluir este produto?", "Confirmar Exclusão", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    Produtos produto = new Produtos();
                    produto.IdProduto = int.Parse(txtID.Text);

                    if (produto.ExcluirProduto())
                    {
                        MessageBox.Show("Produto excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LimparCampos();
                        produto.ListarTodosProdutos(dataGridProdutos);
                    }
                    else
                    {
                        MessageBox.Show("Erro ao excluir o produto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir o produto.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Evento que preenche os campos do formulário ao dar duplo clique em um produto no DataGridView
        private void dataGridProdutos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow linha = dataGridProdutos.Rows[e.RowIndex];

                    txtID.Text = linha.Cells["id_produto"].Value.ToString();
                    txtNomeP.Text = linha.Cells["nome"].Value.ToString();
                    txtPrecoP.Text = linha.Cells["preco"].Value.ToString();
                    txtQtEstoque.Text = linha.Cells["quantidade"].Value.ToString();
                    cbxCategoria.Text = linha.Cells["nome_categoria"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Evento pesquisa produtos por nome ou categoria conforme o texto digitado
        private void txtBusca_TextChanged(object sender, EventArgs e)
        {
            string textoBusca = txtBusca.Text;

            Produtos produto = new Produtos();
            DataTable tabela = produto.BuscarProdutoPorNomeOuCategoria(textoBusca);

            if (tabela != null)
            {
                dataGridProdutos.DataSource = tabela;
            }
        }
    }
}