namespace GestaoProdutos
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }
        public void adicionarUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            pnlCadastro.Controls.Clear();
            pnlCadastro.Controls.Add(userControl);
            userControl.BringToFront();

        }
        public void llblLogin_LinkClicked(object sender, EventArgs e)
        {
            Login login = new Login();
            adicionarUserControl(login);
        }

    }
}
