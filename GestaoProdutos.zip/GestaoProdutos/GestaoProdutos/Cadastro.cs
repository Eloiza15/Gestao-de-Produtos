using Microsoft.VisualBasic.Logging;

namespace GestaoProdutos
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }

        // M�todo para adicionar um UserControl na tela
        public void adicionarUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            pnlCadastro.Controls.Clear();
            pnlCadastro.Controls.Add(userControl);
            userControl.BringToFront();
        }

        // Evento ao clicar no link de login
        public void llblLogin_LinkClicked(object sender, EventArgs e)
        {
            Login login = new Login();
            adicionarUserControl(login);
        }

        // M�todo para limpar os campos ap�s o cadastro
        private void LimparCampos()
        {
            txtNome.Clear();
            txtEmail.Clear();
            txtCPF.Clear();
            txtNomeUsu.Clear();
            txtSenha.Clear();
        }

        // Evento ao clicar no bot�o de cadastrar
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar se os campos obrigat�rios est�o preenchidos
                if (!txtNome.Text.Equals("") && !txtEmail.Text.Equals("") && !txtSenha.Text.Equals("") && !txtCPF.Text.Equals("") && !txtNomeUsu.Text.Equals(""))
                {
                    // Criar uma inst�ncia da classe Usuarios com os dados do formul�rio
                    Usuarios usuario = new Usuarios(txtNome.Text, txtEmail.Text, txtSenha.Text, txtNomeUsu.Text, txtCPF.Text, txtEmail.Text); // Considerando o login como e-mail

                    // Validar se o CPF e o E-mail s�o v�lidos
                    if (!Usuarios.ValidarCPF(usuario.Cpf))
                    {
                        MessageBox.Show("CPF inv�lido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!Usuarios.verificarEmail(usuario.Email))
                    {
                        MessageBox.Show("E-mail inv�lido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Verificar se o e-mail ou CPF j� est�o cadastrados no banco
                    if (usuario.UsuarioExiste(usuario.Email, usuario.Cpf))
                    {
                        MessageBox.Show("E-mail ou CPF j� cadastrados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Cadastrar o usu�rio, criptografando a senha antes de salvar
                    if (usuario.CadastrarUsuario())
                    {
                        MessageBox.Show("Cadastro realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Cria uma nova inst�ncia do formul�rio de gerenciamento de produtos,
                        // passando como par�metro o objeto "usuario" que acabou de ser cadastrado.
                        // Isso permite exibir, por exemplo, o nome do usu�rio na nova tela.
                        Form GerenciamentoProdutos = new GerenciamentoProdutos(usuario);
                        GerenciamentoProdutos.Show();
                        this.Hide();

                        LimparCampos();  
                    }
                    else
                    {
                        MessageBox.Show("Falha ao cadastrar usu�rio.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos corretamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar usu�rio: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Evento para o campo de senha
        private void txtSenha_Enter(object sender, EventArgs e)
        {
            if (txtSenha.Text == "Senha")
            {
                txtSenha.Text = "";
                txtSenha.ForeColor = System.Drawing.Color.Black;
            }
        }

        // Evento para o campo de senha ao perder o foco
        private void txtSenha_Leave(object sender, EventArgs e)
        {
            if (txtSenha.Text == "")
            {
                txtSenha.Text = "Senha";
                txtSenha.ForeColor = System.Drawing.Color.Silver;
            }
        }
    }
}
