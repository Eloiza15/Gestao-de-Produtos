﻿using MySql.Data.MySqlClient;

namespace GestaoProdutos
{
    public class ConexaoBD
    {
        //String de Conexão
        private string conexaoBanco = "Server=localhost; Database=gestao_produtos; Uid=root; Pwd='';";

        public MySqlConnection Conectar()
        {
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);
            conexao.Open();
            return conexao;
        }
    }
}
