﻿namespace GestaoProdutos
{
    partial class GerenciamentoProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GerenciamentoProdutos));
            panel1 = new Panel();
            lblNomeUsu = new Label();
            lblBusca = new Label();
            txtBusca = new TextBox();
            dataGridView1 = new DataGridView();
            btnCadastrar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            lblNomeP = new Label();
            lblPreçoP = new Label();
            lblQtEstoque = new Label();
            lblCategoria = new Label();
            txtNomeP = new TextBox();
            txtPrecoP = new TextBox();
            txtQtEstoque = new TextBox();
            cbxCategoria = new ComboBox();
            lblID = new Label();
            txtID = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(lblNomeUsu);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1165, 35);
            panel1.TabIndex = 0;
            // 
            // lblNomeUsu
            // 
            lblNomeUsu.AutoSize = true;
            lblNomeUsu.ForeColor = Color.Purple;
            lblNomeUsu.Location = new Point(442, 9);
            lblNomeUsu.Name = "lblNomeUsu";
            lblNomeUsu.Size = new Size(212, 29);
            lblNomeUsu.TabIndex = 1;
            lblNomeUsu.Text = "Nome do Usuário";
            // 
            // lblBusca
            // 
            lblBusca.AutoSize = true;
            lblBusca.Location = new Point(21, 63);
            lblBusca.Name = "lblBusca";
            lblBusca.Size = new Size(609, 29);
            lblBusca.TabIndex = 1;
            lblBusca.Text = "Digite a Categoria do Produto que deseja encontrar:";
            // 
            // txtBusca
            // 
            txtBusca.Location = new Point(636, 57);
            txtBusca.Name = "txtBusca";
            txtBusca.Size = new Size(507, 35);
            txtBusca.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(21, 104);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1122, 266);
            dataGridView1.TabIndex = 2;
            // 
            // btnCadastrar
            // 
            btnCadastrar.ForeColor = Color.Purple;
            btnCadastrar.Location = new Point(269, 554);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(143, 37);
            btnCadastrar.TabIndex = 6;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            // 
            // btnEditar
            // 
            btnEditar.ForeColor = Color.Purple;
            btnEditar.Location = new Point(488, 554);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(101, 37);
            btnEditar.TabIndex = 7;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            // 
            // btnExcluir
            // 
            btnExcluir.ForeColor = Color.Purple;
            btnExcluir.Location = new Point(678, 554);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(101, 37);
            btnExcluir.TabIndex = 8;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            // 
            // lblNomeP
            // 
            lblNomeP.AutoSize = true;
            lblNomeP.Location = new Point(21, 446);
            lblNomeP.Name = "lblNomeP";
            lblNomeP.Size = new Size(223, 29);
            lblNomeP.TabIndex = 4;
            lblNomeP.Text = "Nome do Produto:";
            // 
            // lblPreçoP
            // 
            lblPreçoP.AutoSize = true;
            lblPreçoP.Location = new Point(21, 491);
            lblPreçoP.Name = "lblPreçoP";
            lblPreçoP.Size = new Size(223, 29);
            lblPreçoP.TabIndex = 5;
            lblPreçoP.Text = "Preço do Produto:";
            // 
            // lblQtEstoque
            // 
            lblQtEstoque.AutoSize = true;
            lblQtEstoque.Location = new Point(532, 443);
            lblQtEstoque.Name = "lblQtEstoque";
            lblQtEstoque.Size = new Size(292, 29);
            lblQtEstoque.TabIndex = 6;
            lblQtEstoque.Text = "Quantidade em estoque:";
            // 
            // lblCategoria
            // 
            lblCategoria.AutoSize = true;
            lblCategoria.Location = new Point(694, 491);
            lblCategoria.Name = "lblCategoria";
            lblCategoria.Size = new Size(130, 29);
            lblCategoria.TabIndex = 7;
            lblCategoria.Text = "Categoria:";
            // 
            // txtNomeP
            // 
            txtNomeP.Location = new Point(250, 440);
            txtNomeP.MaxLength = 200;
            txtNomeP.Name = "txtNomeP";
            txtNomeP.Size = new Size(220, 35);
            txtNomeP.TabIndex = 2;
            // 
            // txtPrecoP
            // 
            txtPrecoP.Location = new Point(250, 491);
            txtPrecoP.MaxLength = 200;
            txtPrecoP.Name = "txtPrecoP";
            txtPrecoP.Size = new Size(220, 35);
            txtPrecoP.TabIndex = 3;
            // 
            // txtQtEstoque
            // 
            txtQtEstoque.Location = new Point(843, 440);
            txtQtEstoque.MaxLength = 50000;
            txtQtEstoque.Name = "txtQtEstoque";
            txtQtEstoque.Size = new Size(220, 35);
            txtQtEstoque.TabIndex = 4;
            // 
            // cbxCategoria
            // 
            cbxCategoria.FormattingEnabled = true;
            cbxCategoria.Location = new Point(843, 488);
            cbxCategoria.Name = "cbxCategoria";
            cbxCategoria.Size = new Size(220, 37);
            cbxCategoria.TabIndex = 5;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Location = new Point(21, 398);
            lblID.Name = "lblID";
            lblID.Size = new Size(44, 29);
            lblID.TabIndex = 12;
            lblID.Text = "ID:";
            // 
            // txtID
            // 
            txtID.Location = new Point(71, 395);
            txtID.Name = "txtID";
            txtID.ReadOnly = true;
            txtID.Size = new Size(100, 35);
            txtID.TabIndex = 13;
            // 
            // GerenciamentoProdutos
            // 
            AutoScaleDimensions = new SizeF(15F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1165, 618);
            Controls.Add(txtID);
            Controls.Add(lblID);
            Controls.Add(cbxCategoria);
            Controls.Add(txtQtEstoque);
            Controls.Add(txtPrecoP);
            Controls.Add(txtNomeP);
            Controls.Add(lblCategoria);
            Controls.Add(lblQtEstoque);
            Controls.Add(lblPreçoP);
            Controls.Add(lblNomeP);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnCadastrar);
            Controls.Add(dataGridView1);
            Controls.Add(txtBusca);
            Controls.Add(lblBusca);
            Controls.Add(panel1);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "GerenciamentoProdutos";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Gerenciamento de Produtos";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label lblNomeUsu;
        private Label lblBusca;
        private TextBox txtBusca;
        private DataGridView dataGridView1;
        private Button btnCadastrar;
        private Button btnEditar;
        private Button btnExcluir;
        private Label lblNomeP;
        private Label lblPreçoP;
        private Label lblQtEstoque;
        private Label lblCategoria;
        private TextBox txtNomeP;
        private TextBox txtPrecoP;
        private TextBox txtQtEstoque;
        private ComboBox cbxCategoria;
        private Label lblID;
        private TextBox txtID;
    }
}