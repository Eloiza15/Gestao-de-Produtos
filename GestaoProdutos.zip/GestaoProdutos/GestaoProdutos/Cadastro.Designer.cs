﻿namespace GestaoProdutos
{
    partial class Cadastro
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro));
            pnlCadastro = new Panel();
            panel1 = new Panel();
            llblLogin = new LinkLabel();
            txtSenha = new TextBox();
            txtNomeUsu = new TextBox();
            txtCPF = new MaskedTextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            lblSenha = new Label();
            lblNomeUsu = new Label();
            lblCPF = new Label();
            lblEmail = new Label();
            lblNome = new Label();
            lblNomeTela = new Label();
            btnCadastrar = new Button();
            pnlCadastro.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pnlCadastro
            // 
            pnlCadastro.Controls.Add(btnCadastrar);
            pnlCadastro.Controls.Add(panel1);
            pnlCadastro.Controls.Add(txtSenha);
            pnlCadastro.Controls.Add(txtNomeUsu);
            pnlCadastro.Controls.Add(txtCPF);
            pnlCadastro.Controls.Add(txtEmail);
            pnlCadastro.Controls.Add(txtNome);
            pnlCadastro.Controls.Add(lblSenha);
            pnlCadastro.Controls.Add(lblNomeUsu);
            pnlCadastro.Controls.Add(lblCPF);
            pnlCadastro.Controls.Add(lblEmail);
            pnlCadastro.Controls.Add(lblNome);
            pnlCadastro.Controls.Add(lblNomeTela);
            pnlCadastro.Dock = DockStyle.Fill;
            pnlCadastro.Location = new Point(0, 0);
            pnlCadastro.Margin = new Padding(4);
            pnlCadastro.Name = "pnlCadastro";
            pnlCadastro.Size = new Size(773, 397);
            pnlCadastro.TabIndex = 0;
            // 
            // panel1
            // 
            panel1.Controls.Add(llblLogin);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 354);
            panel1.Name = "panel1";
            panel1.Size = new Size(773, 43);
            panel1.TabIndex = 7;
            // 
            // llblLogin
            // 
            llblLogin.AutoSize = true;
            llblLogin.ForeColor = SystemColors.ControlText;
            llblLogin.Location = new Point(228, 13);
            llblLogin.Name = "llblLogin";
            llblLogin.Size = new Size(356, 19);
            llblLogin.TabIndex = 6;
            llblLogin.TabStop = true;
            llblLogin.Text = "Já é cadastrado? Clique aqui para fazer login.";
            llblLogin.LinkClicked += llblLogin_LinkClicked;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(228, 264);
            txtSenha.MaxLength = 8;
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(332, 26);
            txtSenha.TabIndex = 5;
            // 
            // txtNomeUsu
            // 
            txtNomeUsu.Location = new Point(228, 225);
            txtNomeUsu.MaxLength = 200;
            txtNomeUsu.Name = "txtNomeUsu";
            txtNomeUsu.Size = new Size(332, 26);
            txtNomeUsu.TabIndex = 4;
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(228, 184);
            txtCPF.Mask = "000.000.000-00";
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(332, 26);
            txtCPF.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(228, 146);
            txtEmail.MaxLength = 200;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(332, 26);
            txtEmail.TabIndex = 2;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(228, 104);
            txtNome.MaxLength = 200;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(332, 26);
            txtNome.TabIndex = 1;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(62, 267);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(64, 19);
            lblSenha.TabIndex = 5;
            lblSenha.Text = "Senha:";
            // 
            // lblNomeUsu
            // 
            lblNomeUsu.AutoSize = true;
            lblNomeUsu.Location = new Point(62, 228);
            lblNomeUsu.Margin = new Padding(4, 0, 4, 0);
            lblNomeUsu.Name = "lblNomeUsu";
            lblNomeUsu.Size = new Size(147, 19);
            lblNomeUsu.TabIndex = 4;
            lblNomeUsu.Text = "Nome de Usuário:";
            // 
            // lblCPF
            // 
            lblCPF.AutoSize = true;
            lblCPF.Location = new Point(62, 187);
            lblCPF.Margin = new Padding(4, 0, 4, 0);
            lblCPF.Name = "lblCPF";
            lblCPF.Size = new Size(48, 19);
            lblCPF.TabIndex = 3;
            lblCPF.Text = "CPF:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(62, 149);
            lblEmail.Margin = new Padding(4, 0, 4, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(62, 19);
            lblEmail.TabIndex = 2;
            lblEmail.Text = "E-mail:";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(62, 111);
            lblNome.Margin = new Padding(4, 0, 4, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(60, 19);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome:";
            // 
            // lblNomeTela
            // 
            lblNomeTela.AutoSize = true;
            lblNomeTela.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNomeTela.ForeColor = Color.Indigo;
            lblNomeTela.Location = new Point(291, 47);
            lblNomeTela.Margin = new Padding(4, 0, 4, 0);
            lblNomeTela.Name = "lblNomeTela";
            lblNomeTela.Size = new Size(211, 22);
            lblNomeTela.TabIndex = 0;
            lblNomeTela.Text = "Cadastro de Usuários";
            // 
            // btnCadastrar
            // 
            btnCadastrar.Location = new Point(329, 306);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(128, 30);
            btnCadastrar.TabIndex = 6;
            btnCadastrar.Text = "Cadastrar-se";
            btnCadastrar.UseVisualStyleBackColor = true;
            // 
            // Cadastro
            // 
            AutoScaleDimensions = new SizeF(10F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(773, 397);
            Controls.Add(pnlCadastro);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "Cadastro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cadastro";
            pnlCadastro.ResumeLayout(false);
            pnlCadastro.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlCadastro;
        private Label lblNomeUsu;
        private Label lblCPF;
        private Label lblEmail;
        private Label lblNome;
        private Label lblNomeTela;
        private Label lblSenha;
        private TextBox txtNome;
        private LinkLabel llblLogin;
        private TextBox txtSenha;
        private TextBox txtNomeUsu;
        private MaskedTextBox txtCPF;
        private TextBox txtEmail;
        private Panel panel1;
        private Button btnCadastrar;
    }
}
