﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace GestaoProdutos
{
    public class Produtos
    {
        // Atributos
        private int id_produto;
        private string nome;
        private decimal preco;
        private int quantidade;
        private int id_categoria;

        // Métodos Get e Set
        public int IdProduto
        {
            get { return id_produto; }
            set { id_produto = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public decimal Preco
        {
            get { return preco; }
            set { preco = value; }
        }

        public int Quantidade
        {
            get { return quantidade; }
            set { quantidade = value; }
        }

        public int IdCategoria
        {
            get { return id_categoria; }
            set { id_categoria = value; }
        }

        // Método de Inserir Produto
        public bool InserirProduto()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
                {
                    string inserir = "INSERT INTO produtos (nome, preco, quantidade, id_categoria) VALUES (@nome, @preco, @quantidade, @id_categoria);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@preco", Preco);
                    comando.Parameters.AddWithValue("@quantidade", Quantidade);
                    comando.Parameters.AddWithValue("@id_categoria", IdCategoria);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir produto: " + ex.Message, "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        // Método de Atualizar Produto
        public bool AtualizarProduto()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
                {
                    string atualizar = "UPDATE produtos SET nome = @nome, preco = @preco, quantidade = @quantidade, id_categoria = @id_categoria WHERE id_produto = @id_produto;";

                    MySqlCommand comando = new MySqlCommand(atualizar, conexaoBanco);
                    comando.Parameters.AddWithValue("@id_produto", IdProduto);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@preco", Preco);
                    comando.Parameters.AddWithValue("@quantidade", Quantidade);
                    comando.Parameters.AddWithValue("@id_categoria", IdCategoria);

                    int resultado = comando.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar produto: " + ex.Message, "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        // Método de Excluir Produto
        public bool ExcluirProduto()
        {
            try
            {
                if (id_produto > 0)
                {
                    var resultado = MessageBox.Show("Você tem certeza que deseja excluir esse produto?", "Confirmar exclusão", MessageBoxButtons.YesNo);
                    if (resultado == DialogResult.Yes)
                    {
                        using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
                        {
                            string excluir = "DELETE FROM produtos WHERE id_produto = @id_produto;";

                            MySqlCommand comando = new MySqlCommand(excluir, conexaoBanco);
                            comando.Parameters.AddWithValue("@id_produto", IdProduto);

                            int resultadoConsulta = comando.ExecuteNonQuery();
                            if (resultadoConsulta > 0)
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("O produto não foi deletado!");
                        return false;
                    }
                }
                else
                {
                    MessageBox.Show("Selecione um produto para excluir!");
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        // Método de Listar Todos Produtos
        public bool ListarTodosProdutos(DataGridView dataGrid)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string listar = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, c.nome_categoria FROM produtos p INNER JOIN categorias c ON p.id_categoria = c.id_categoria;";
                    MySqlCommand comando = new MySqlCommand(listar, conexao);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    // Configurações do DataGridView
                    dataGrid.AllowUserToAddRows = false;  // Impede a adição de novas linhas manualmente
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;  // Ajusta as colunas automaticamente
                    dataGrid.AutoResizeColumns();  // Redimensiona as colunas
                    dataGrid.ClearSelection();  // Limpa a seleção das células

                    // Verifica se há registros e retorna true ou false
                    if (dataGrid.Rows.Count > 0)
                    {
                        return true;  // Produtos encontrados
                    }
                    else
                    {
                        return false;  // Nenhum produto encontrado
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao listar produtos: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        // Método de Buscar Produtos por Nome
        public DataTable BuscarProdutoPorNome(string nome)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string consulta = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, c.nome_categoria FROM produtos p INNER JOIN categorias c ON p.id_categoria = c.id_categoria WHERE p.nome LIKE @nome";
                    MySqlCommand comando = new MySqlCommand(consulta, conexao);

                    comando.Parameters.AddWithValue("@nome", "%" + nome + "%");

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    return tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar produto por nome: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        // Método de Buscar Produtos por Categoria
        public DataTable BuscarProdutoPorCategoria(int idCategoria)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string consulta = "SELECT p.id_produto, p.nome, p.preco, p.quantidade, c.nome_categoria FROM produtos p INNER JOIN categorias c ON p.id_categoria = c.id_categoria WHERE p.id_categoria = @id_categoria";
                    MySqlCommand comando = new MySqlCommand(consulta, conexao);

                    comando.Parameters.AddWithValue("@id_categoria", idCategoria);

                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);

                    return tabela;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao buscar produto por categoria: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }
    }
}

