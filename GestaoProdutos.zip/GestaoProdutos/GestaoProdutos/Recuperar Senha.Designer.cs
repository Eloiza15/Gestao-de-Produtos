﻿namespace GestaoProdutos
{
    partial class Recuperar_Senha
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lblEmail = new Label();
            lblNomeTela = new Label();
            lblNovaSenha = new Label();
            btnRedefinir = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            SuspendLayout();
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(141, 135);
            lblEmail.Margin = new Padding(4, 0, 4, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(92, 29);
            lblEmail.TabIndex = 0;
            lblEmail.Text = "E-mail:";
            // 
            // lblNomeTela
            // 
            lblNomeTela.AutoSize = true;
            lblNomeTela.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNomeTela.ForeColor = Color.Indigo;
            lblNomeTela.Location = new Point(272, 52);
            lblNomeTela.Margin = new Padding(6, 0, 6, 0);
            lblNomeTela.Name = "lblNomeTela";
            lblNomeTela.Size = new Size(236, 34);
            lblNomeTela.TabIndex = 2;
            lblNomeTela.Text = "Redefinir Senha";
            // 
            // lblNovaSenha
            // 
            lblNovaSenha.AutoSize = true;
            lblNovaSenha.Location = new Point(99, 176);
            lblNovaSenha.Name = "lblNovaSenha";
            lblNovaSenha.Size = new Size(157, 29);
            lblNovaSenha.TabIndex = 3;
            lblNovaSenha.Text = "Nova Senha:";
            // 
            // btnRedefinir
            // 
            btnRedefinir.ForeColor = Color.Black;
            btnRedefinir.Location = new Point(317, 265);
            btnRedefinir.Name = "btnRedefinir";
            btnRedefinir.Size = new Size(154, 38);
            btnRedefinir.TabIndex = 3;
            btnRedefinir.Text = "Redefinir Senha";
            btnRedefinir.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(262, 132);
            textBox1.MaxLength = 200;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(332, 35);
            textBox1.TabIndex = 1;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(262, 173);
            textBox2.MaxLength = 8;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(332, 35);
            textBox2.TabIndex = 2;
            // 
            // Recuperar_Senha
            // 
            AutoScaleDimensions = new SizeF(15F, 29F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btnRedefinir);
            Controls.Add(lblNovaSenha);
            Controls.Add(lblNomeTela);
            Controls.Add(lblEmail);
            Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Recuperar_Senha";
            Size = new Size(773, 397);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblEmail;
        private Label lblNomeTela;
        private Label lblNovaSenha;
        private Button btnRedefinir;
        private TextBox textBox1;
        private TextBox textBox2;
    }
}
