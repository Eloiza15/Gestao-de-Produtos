﻿namespace GestaoProdutos
{
    public partial class Login : UserControl
    {
        public Login()
        {
            InitializeComponent();
        }

        // Evento disparado ao clicar no link "Fazer Cadastro"
        // Abre o formulário de cadastro em uma nova janela
        private void llblFazerCadastro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cadastro cadastroForm = new Cadastro();
            cadastroForm.Show();
        }

        // Evento disparado ao clicar no link "Esqueci minha senha"
        // Substitui o conteúdo atual do formulário pelo UserControl de recuperação de senha
        private void llblEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cadastro formPrincipal = this.FindForm() as Cadastro;

            if (formPrincipal != null)
            {
                Recuperar_Senha recuperarSenha = new Recuperar_Senha();

                formPrincipal.adicionarUserControl(recuperarSenha);
            }
        }

        // Método para limpar os campos após o Login
        private void LimparCampos()
        {
            txtNomeUsuorSenha.Clear();
            txtSenha.Clear();
        }

        // Evento ao clicar no botão de login
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string login = txtNomeUsuorSenha.Text;
                string senha = txtSenha.Text;

                // 1. Verifica se os campos estão preenchidos
                if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(senha))
                {
                    MessageBox.Show("Preencha todos os campos corretamente.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Verifica se o login (e-mail ou nome de usuário) existe no banco

                if (!Usuarios.LoginExiste(login))
                {
                    MessageBox.Show("Usuário não encontrado!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 3. Verifica se o login e a senha fornecida são válidos
                if (Usuarios.ValidarLogin(login, senha))
                {
                    // Tenta buscar o usuário autenticado com base no login (nome de usuário ou e-mail) e senha digitados
                    Usuarios usuarioLogado = Usuarios.BuscarUsuarioAutenticado(login, senha);// Obtém o objeto com os dados do usuário autenticado

                    if (usuarioLogado != null)
                    {
                        MessageBox.Show("Login realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Cria uma nova instância do formulário de gerenciamento de produtos,
                        // passando como parâmetro o objeto "usuario", que foi autenticado com sucesso.
                        // Esse objeto contém as informações completas do usuário logado (nome, e-mail, etc.).
                        Form formPrincipal = new GerenciamentoProdutos(usuarioLogado);
                        formPrincipal.Show();
                        this.Hide();

                        LimparCampos();
                    }
                    else
                    {
                        MessageBox.Show("Erro ao obter informações do usuário!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao realizar login: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
