﻿namespace GestaoProdutos
{
    public partial class Login : UserControl
    {
        public Login()
        {
            InitializeComponent();
        }

        private void llblFazerCadastro_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cadastro cadastroForm = new Cadastro();
            cadastroForm.Show();
        }

        private void llblEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cadastro formPrincipal = this.FindForm() as Cadastro;

            if (formPrincipal != null)
            {
                Recuperar_Senha recuperarSenha = new Recuperar_Senha();

                formPrincipal.adicionarUserControl(recuperarSenha);
            }
        }
    }
}
